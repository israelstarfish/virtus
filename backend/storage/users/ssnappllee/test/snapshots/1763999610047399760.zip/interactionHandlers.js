const { EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, ActionRowBuilder, ButtonBuilder, ButtonStyle, ChannelType, PermissionsBitField } = require('discord.js');
const randomstring = require('randomstring');
const { getChannelsCollection } = require('./database');
const { monitorChannelActivity, getCategoryForChannel, getResponseByCategory } = require('./channelUtils');

const captchaAnswers = {};

function generateCaptcha(categoryId) {
    const num1 = Math.floor(Math.random() * 10);
    const num2 = Math.floor(Math.random() * 10);
    const operations = ['+', '-', '*'];
    const operation = operations[Math.floor(Math.random() * operations.length)];
    let question, answer;

    switch (operation) {
        case '+':
            question = getResponseByCategory(categoryId, {
                en: `What is the sum of ${num1} + ${num2}?`,
                es: `¿Cuál es la suma de ${num1} + ${num2}?`,
                pt: `Qual é a soma de ${num1} + ${num2}?`
            });
            answer = (num1 + num2).toString();
            break;
        case '-':
            question = getResponseByCategory(categoryId, {
                en: `What is the difference of ${num1} - ${num2}?`,
                es: `¿Cuál es la diferencia de ${num1} - ${num2}?`,
                pt: `Qual é a diferença de ${num1} - ${num2}?`
            });
            answer = (num1 - num2).toString();
            break;
        case '*':
            question = getResponseByCategory(categoryId, {
                en: `What is the product of ${num1} x ${num2}?`,
                es: `¿Cuál es el producto de ${num1} x ${num2}?`,
                pt: `Qual é o produto de ${num1} x ${num2}?`
            });
            answer = (num1 * num2).toString();
            break;
    }
    return { question, answer };
}

async function handleInteraction(interaction) {
    try {
        const categoryId = getCategoryForChannel(interaction);

        if (interaction.customId === 'create_channel') {
            const captcha = generateCaptcha(categoryId);

            const modal = new ModalBuilder()
                .setCustomId(`captcha_modal_${interaction.id}`)
                .setTitle(getResponseByCategory(categoryId, {
                    en: 'Create Channel | Anti-Spam Protection',
                    es: 'Crear Canal | Protección Anti-Spam',
                    pt: 'Criar canal | Proteção anti-spam'
                }));

            const textInput = new TextInputBuilder()
                .setCustomId('captcha_answer')
                .setLabel(captcha.question)
                .setStyle(TextInputStyle.Short)
                .setRequired(true);

            modal.addComponents(new ActionRowBuilder().addComponents(textInput));

            captchaAnswers[interaction.id] = captcha.answer;

            await interaction.showModal(modal);
        } else if (interaction.isModalSubmit() && interaction.customId.startsWith('captcha_modal_')) {
            const modalId = interaction.customId.split('_').pop();
            const answer = interaction.fields.getTextInputValue('captcha_answer');
            const correctAnswer = captchaAnswers[modalId];

            if (answer === correctAnswer) {  // Resposta correta do captcha
                const existingChannels = interaction.guild.channels.cache.filter(channel => channel.name.startsWith(`💠┇${interaction.user.username}`) && channel.parentId === categoryId);

                if (existingChannels.size >= 2) {
                    const emptyChannels = existingChannels.filter(channel => channel.members.size === 0);

                    if (emptyChannels.size > 0) {
                        const responseText = getResponseByCategory(categoryId, {
                            en: 'You already have the maximum of 2 voice channels. Delete an empty channel to create a new one.',
                            es: 'Ya tienes el máximo de 2 canales de voz. Elimina un canal vacío para crear uno nuevo.',
                            pt: 'Você já possui o máximo de 2 canais de voz. Exclua um dos canais vazios para criar um novo.'
                        });

                        await interaction.reply({
                            content: responseText,
                            ephemeral: true
                        });

                        const row = new ActionRowBuilder()
                            .addComponents(
                                emptyChannels.map(channel => new ButtonBuilder()
                                    .setCustomId(`delete_channel_${channel.id}`)
                                    .setLabel(getResponseByCategory(categoryId, {
                                        en: `Delete ${channel.name}`,
                                        es: `Eliminar ${channel.name}`,
                                        pt: `Excluir ${channel.name}`
                                    }))
                                    .setStyle(ButtonStyle.Danger))
                            );

                        await interaction.followUp({
                            content: getResponseByCategory(categoryId, {
                                en: 'Choose a channel to delete:',
                                es: 'Elige un canal para eliminar:',
                                pt: 'Escolha um canal para excluir:'
                            }), components: [row], ephemeral: true });
                    } else {
                        const responseText = getResponseByCategory(categoryId, {
                            en: 'You already have the maximum of 2 voice channels and all are occupied.',
                            es: 'Ya tienes el máximo de 2 canales de voz y todos están ocupados.',
                            pt: 'Você já possui o máximo de 2 canais de voz e todos estão ocupados.'
                        });

                        await interaction.reply({ content: responseText, ephemeral: true });
                    }
                    return;
                }

                const password = randomstring.generate({ length: 6, charset: 'alphanumeric', capitalization: 'lowercase' });
                const expirationTime = new Date(Date.now() + 120 * 1000); // 120 segundos
                const channelName = `💠┇${interaction.user.username}-${String(existingChannels.size + 1).padStart(3, '0')}`;
                const channel = await interaction.guild.channels.create({
                    name: channelName,
                    type: ChannelType.GuildVoice,
                    parent: categoryId,
                    permissionOverwrites: [
                        {
                            id: interaction.guild.id,
                            deny: [PermissionsBitField.Flags.Connect, PermissionsBitField.Flags.ViewChannel]
                        },
                        {
                            id: interaction.user.id,
                            allow: [
                                PermissionsBitField.Flags.Connect,
                                PermissionsBitField.Flags.ViewChannel,
                                PermissionsBitField.Flags.SendMessages,
                                PermissionsBitField.Flags.Speak,
                                PermissionsBitField.Flags.Stream,
                                PermissionsBitField.Flags.MoveMembers // Permissão para desconectar usuários
                            ]
                        }
                    ]
                });

                const dbChannelsCollection = await getChannelsCollection();
                await dbChannelsCollection.insertOne({ password, channelId: channel.id, expirationTime, createdAt: new Date(), createdBy: interaction.user.id });

                const confirmationEmbed = new EmbedBuilder()
                    .setColor('#FFFF00') // Amarelo
                    .setTitle(getResponseByCategory(categoryId, {
                        en: 'Your channel has been created',
                        es: 'Tu canal ha sido creado',
                        pt: 'Seu canal foi criado'
                    }))
                    .setDescription(getResponseByCategory(categoryId, {
                        en: 'Below, you will find a password that will allow you to access it. Click on the password to reveal it and share it with your teammates.',
                        es: 'A continuación, encontrarás una contraseña que te permitirá acceder a ella. Haz clic en la contraseña para revelarla y compártela con tus compañeros de equipo.',
                        pt: 'Abaixo, você encontrará uma senha que lhe permitirá acessá-lo. Clique na senha para revelá-la e compartilhe-a com seus colegas de equipe.'
                    }))
                    .addFields({ name: getResponseByCategory(categoryId, {
                        en: 'Password:',
                        es: 'Contraseña:',
                        pt: 'Senha:'
                    }), value: `||${password}||` });

                await channel.send({ content: '@here', embeds: [confirmationEmbed] });

                await interaction.reply({ embeds: [confirmationEmbed], ephemeral: true });

                monitorChannelActivity(channel);
            } else {
                const errorEmbed = new EmbedBuilder()
                    .setColor('#FF0000') // Vermelho
                    .setTitle(getResponseByCategory(categoryId, {
                        en: '**Anti-Spam Protection**',
                        es: '**Protección Anti-Spam**',
                        pt: '**Proteção anti-spam**'
                    }))
                    .setDescription(getResponseByCategory(categoryId, {
                        en: 'Captcha could not be validated. Check your answer and try again. If you continue to have problems, contact us for assistance.',
                        es: 'No se pudo validar el captcha. Verifica tu respuesta e inténtalo de nuevo. Si continúas teniendo problemas, contáctanos para obtener ayuda.',
                        pt: 'Captcha não pôde ser validado. Verifique sua resposta e tente novamente. Se você continuar a ter problemas, entre em contato conosco para obter assistência.'
                    }));

                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        } else if (interaction.customId === 'join_channel') {
            const modal = new ModalBuilder()
                .setCustomId(`join_channel_modal_${interaction.id}`)
                .setTitle(getResponseByCategory(categoryId, {
                    en: 'Join Channel',
                    es: 'Unirse al Canal',
                    pt: 'Entrar no Canal'
                }));

            const textInput = new TextInputBuilder()
            .setCustomId('channel_password') 
            .setLabel(getResponseByCategory(categoryId, { 
                en: 'Channel password', 
                es: 'Contraseña del canal', 
                pt: 'Senha do canal'
            }))
            .setStyle(TextInputStyle.Short)
            .setRequired(true)
            .setMinLength(5);

        modal.addComponents(new ActionRowBuilder().addComponents(textInput));

        await interaction.showModal(modal);
    } else if (interaction.isModalSubmit() && interaction.customId.startsWith('join_channel_modal_')) {
        const password = interaction.fields.getTextInputValue('channel_password');

        if (password.length < 5) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000') // Vermelho
                .setTitle(getResponseByCategory(categoryId, {
                    en: '**Invalid Password**',
                    es: '**Contraseña Inválida**',
                    pt: '**Senha Inválida**'
                }))
                .setDescription(getResponseByCategory(categoryId, {
                    en: 'The password must be at least 5 characters long. Please try again.',
                    es: 'La contraseña debe tener al menos 5 caracteres. Por favor, inténtalo de nuevo.',
                    pt: 'A senha deve ter no mínimo 5 caracteres. Por favor, tente novamente.'
                }));

            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            return;
        }

        const dbChannelsCollection = await getChannelsCollection();
        const channelData = await dbChannelsCollection.findOne({ password: password });

        if (channelData) {
            const channel = interaction.guild.channels.cache.get(channelData.channelId);

            if (channel) {
                if (new Date() > channelData.expirationTime) {
                    await channel.delete();
                    await dbChannelsCollection.deleteOne({ channelId: channelData.channelId });
                    const errorEmbed = new EmbedBuilder()
                        .setColor('#FF0000') // Vermelho
                        .setTitle(getResponseByCategory(categoryId, {
                            en: '**Voice Channel Expired**',
                            es: '**Canal de Voz Expirado**',
                            pt: '**Canal de voz expirado**'
                        }))
                        .setDescription(getResponseByCategory(categoryId, {
                            en: 'The voice channel you are trying to access has expired and has been deleted. Please create a new channel.',
                            es: 'El canal de voz que estás intentando acceder ha expirado y ha sido eliminado. Por favor, crea un nuevo canal.',
                            pt: 'O canal de voz que você está tentando acessar expirou e foi excluído. Por favor, crie um novo canal.'
                        }));

                    await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
                    return;
                }

                await channel.permissionOverwrites.edit(interaction.user.id, {
                    Connect: true,
                    ViewChannel: true,
                    SendMessages: false,
                    Speak: true,
                    Stream: true
                });

                const welcomeEmbed = new EmbedBuilder()
                    .setColor('#00FF00') // Verde
                    .setDescription(getResponseByCategory(categoryId, {
                        en: `@${interaction.user.username} has joined the channel!`,
                        es: `@${interaction.user.username} se ha unido al canal!`,
                        pt: `@${interaction.user.username} agora faz parte do canal!`
                    }));

                await channel.send({ embeds: [welcomeEmbed] });

                await interaction.reply({ embeds: [welcomeEmbed], ephemeral: true });
            } else {
                const errorEmbed = new EmbedBuilder()
                    .setColor('#FF0000') // Vermelho
                    .setTitle(getResponseByCategory(categoryId, {
                        en: '**Voice Channel Not Found**',
                        es: '**Canal de Voz No Encontrado**',
                        pt: '**Canal de voz não encontrado**'
                    }))
                    .setDescription(getResponseByCategory(categoryId, {
                        en: 'The voice channel you are looking for was not found. Please check if you entered the correct password and try again.',
                        es: 'El canal de voz que estás buscando no fue encontrado. Verifica si ingresaste la contraseña correcta y vuelve a intentarlo.',
                        pt: 'O canal de voz que você está procurando não foi encontrado. Verifique se você digitou a senha correta e tente novamente.'
                    }));

                await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
            }
        } else {
            const errorEmbed = new EmbedBuilder()
                .setColor('#FF0000') // Vermelho
                .setTitle(getResponseByCategory(categoryId, {
                    en: '**Voice Channel Not Found**',
                    es: '**Canal de Voz No Encontrado**',
                    pt: '**Canal de voz não encontrado**'
                }))
                .setDescription(getResponseByCategory(categoryId, {
                    en: 'The voice channel you are looking for was not found. Please check if you entered the correct password and try again.',
                    es: 'El canal de voz que estás buscando no fue encontrado. Verifica si ingresaste la contraseña correcta y vuelve a intentarlo.',
                    pt: 'O canal de voz que você está procurando não foi encontrado. Verifique se você digitou a senha correta e tente novamente.'
                }));

            await interaction.reply({ embeds: [errorEmbed], ephemeral: true });
        }
    } else if (interaction.customId.startsWith('delete_channel_')) {
        const channelId = interaction.customId.split('_').pop();
        const channel = interaction.guild.channels.cache.get(channelId);

        if (channel) {
            if (channel.members.size === 0) {
                await channel.delete();
                const dbChannelsCollection = await getChannelsCollection();
                await dbChannelsCollection.deleteOne({ channelId: channelId });
                await interaction.reply({ content: getResponseByCategory(categoryId, {
                    en: `Channel ${channel.name} deleted. You can now create a new channel.`,
                    es: `Canal ${channel.name} eliminado. Ahora puedes crear un nuevo canal.`,
                    pt: `Canal ${channel.name} excluído. Você pode agora criar um novo canal.`
                }), ephemeral: true });
            } else {
                await interaction.reply({ content: getResponseByCategory(categoryId, {
                    en: 'Could not delete the channel because it is not empty.',
                    es: 'No se pudo eliminar el canal porque no está vacío.',
                    pt: 'Não foi possível excluir o canal, pois ele não está vazio.'
                }), ephemeral: true });
            }
        } else {
            await interaction.reply({ content: getResponseByCategory(categoryId, {
                en: 'Channel not found.',
                es: 'Canal no encontrado.',
                pt: 'Canal não encontrado.'
            }), ephemeral: true });
        }
    }
} catch (error) {
    console.error('Erro na interação:', error);
    await interaction.reply({
        content: getResponseByCategory(getCategoryForChannel(interaction), {
            en: 'An error occurred while processing your request. Please try again later.',
            es: 'Ocurrió un error al procesar tu solicitud. Por favor, inténtalo de nuevo más tarde.',
            pt: 'Ocorreu um erro ao processar sua solicitação. Por favor, tente novamente mais tarde.'
        }),
        ephemeral: true
    });
}
}

async function handleVoiceStateUpdate(oldState, newState) {
// Verifica se o usuário foi desconectado do canal
if (oldState.channelId && !newState.channelId && oldState.channel && oldState.member) {
    const channel = oldState.channel;
    const member = oldState.member;

    const dbChannelsCollection = await getChannelsCollection();
    const channelData = await dbChannelsCollection.findOne({ channelId: channel.id });

    if (channelData && member.id !== channelData.createdBy) {
        const newPassword = randomstring.generate({ length: 6, charset: 'alphanumeric', capitalization: 'lowercase' });
        await dbChannelsCollection.updateOne({ channelId: channel.id }, { $set: { password: newPassword } });

        const newConfirmationEmbed = new EmbedBuilder()
            .setColor('#FFFF00') // Amarelo
            .setTitle(getResponseByCategory(channelData.categoryId, {
                en: 'New Password Generated',
                es: 'Nueva Contraseña Generada',
                pt: 'Nova Senha Gerada'
            }))
            .setDescription(getResponseByCategory(channelData.categoryId, {
                en: 'A new password has been generated for your voice channel. Share this with your teammates.',
                es: 'Se ha generado una nueva contraseña para tu canal de voz. Compártela con tus compañeros de equipo.',
                pt: 'Uma nova senha foi gerada para seu canal de voz. Compartilhe isso com seus colegas de equipe.'
            }))
            .addFields({ name: getResponseByCategory(channelData.categoryId, {
                en: 'New Password:',
                es: 'Nueva Contraseña:',
                pt: 'Nova Senha:'
            }), value: `||${newPassword}||` });

        await channel.send({ embeds: [newConfirmationEmbed] });

        await channel.permissionOverwrites.edit(member.id, {
            Connect: false,
            ViewChannel: false
        });
    }
}
}

module.exports = { handleInteraction, handleVoiceStateUpdate };
