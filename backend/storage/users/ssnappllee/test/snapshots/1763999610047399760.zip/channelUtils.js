const { EmbedBuilder } = require('discord.js');
const { getChannelsCollection } = require('./database');

async function checkInactiveChannels(discordClient) {
    const dbChannelsCollection = await getChannelsCollection();
    const channels = await dbChannelsCollection.find().toArray();
    const now = new Date();

    for (const { channelId, expirationTime, inactivityStartTime } of channels) {
        const channel = discordClient.channels.cache.get(channelId);

        if (channel) {
            if (now > expirationTime) {
                if (channel.members.size === 0) {
                    await channel.delete();
                    await dbChannelsCollection.deleteOne({ channelId });
                    console.log(`Canal de voz ${channel.name} deletado por inatividade.`);
                }
            } else {
                if (channel.members.size === 0 && inactivityStartTime) {
                    const timeSinceInactivity = now - new Date(inactivityStartTime);
                    if (timeSinceInactivity >= 140 * 1000) { // 140 segundos
                        await channel.delete();
                        await dbChannelsCollection.deleteOne({ channelId });
                        console.log(`Canal de voz ${channel.name} deletado por inatividade.`);
                    } else {
                        monitorChannelActivity(channel, expirationTime, inactivityStartTime);
                    }
                } else {
                    monitorChannelActivity(channel, expirationTime, inactivityStartTime);
                }
            }
        }
    }
}

function monitorChannelActivity(channel, expirationTime, inactivityStartTime = null) {
    let inactivityTimeout1 = null;
    let inactivityTimeout2 = null;
    let firstWarningSent = false;
    let secondWarningSent = false;

    const interval = setInterval(async () => {
        if (!channel.guild.channels.cache.has(channel.id)) {
            clearInterval(interval);
            return;
        }

        if (channel.members.size === 0) {
            const now = new Date();
            const timezoneOffset = now.getTimezoneOffset() / 60;
            const timezone = `GMT${timezoneOffset > 0 ? '-' : '+'}${Math.abs(timezoneOffset)}`;

            if (!inactivityStartTime) {
                inactivityStartTime = now;
                const dbChannelsCollection = await getChannelsCollection();
                await dbChannelsCollection.updateOne(
                    { channelId: channel.id },
                    { $set: { inactivityStartTime } }
                );
            }

            const timeSinceInactivity = now - new Date(inactivityStartTime);

            if (timeSinceInactivity >= 60 * 1000 && !firstWarningSent) {
                const nextCheck = new Date(inactivityStartTime.getTime() + 120 * 1000); // 120 segundos

                const warningEmbed1 = new EmbedBuilder()
                    .setColor('#FF0000') // Vermelho
                    .setTitle(getResponseByCategory(channel.parentId, {
                        en: 'Channel inactivity detected',
                        es: 'Inactividad del canal detectada',
                        pt: 'Inatividade do canal detectada'
                    }))
                    .setDescription(getResponseByCategory(channel.parentId, {
                        en: `No active players detected in this voice channel. If no player accesses this channel, it will be deleted during the next check.

**Next Check**
At ${nextCheck.toLocaleTimeString()} ${timezone}`,
                        es: `No se detectaron jugadores activos en este canal de voz. Si ningún jugador accede a este canal, será eliminado durante la próxima verificación.

**Próxima verificación**
A las ${nextCheck.toLocaleTimeString()} ${timezone}`,
                        pt: `Não identificamos nenhum jogador ativo neste canal de voz. Se nenhum jogador acessar este canal, ele será excluído durante a próxima verificação.

**Próxima verificação**
Às ${nextCheck.toLocaleTimeString()} ${timezone}`
                    }));

                await channel.send({ content: '@here', embeds: [warningEmbed1] });
                firstWarningSent = true;

                inactivityTimeout1 = setTimeout(async () => {
                    const deletionCheck = new Date(inactivityStartTime.getTime() + 140 * 1000); // 140 segundos

                    const warningEmbed2 = new EmbedBuilder()
                        .setColor('#FF0000') // Vermelho
                        .setTitle(getResponseByCategory(channel.parentId, {
                            en: 'Channel inactivity detected',
                            es: 'Inactividad del canal detectada',
                            pt: 'Inatividade do canal detectada'
                        }))
                        .setDescription(getResponseByCategory(channel.parentId, {
                            en: `If no player accesses this channel, it will be deleted in 20 seconds.

**Channel Deletion**
At ${deletionCheck.toLocaleTimeString()} ${timezone}`,
                            es: `Si ningún jugador accede a este canal, será eliminado en 20 segundos.

**Eliminación del canal**
A las ${deletionCheck.toLocaleTimeString()} ${timezone}`,
                            pt: `Se nenhum jogador acessar este canal, ele será excluído em 20 segundos.

**Exclusão do canal**
Às ${deletionCheck.toLocaleTimeString()} ${timezone}`
                        }));

                    await channel.send({ content: '@here', embeds: [warningEmbed2] });
                    secondWarningSent = true;

                    inactivityTimeout2 = setTimeout(async () => {
                        if (channel.members.size === 0) {
                            await channel.delete();
                            const dbChannelsCollection = await getChannelsCollection();
                            await dbChannelsCollection.deleteOne({ channelId: channel.id });
                            clearInterval(interval);
                            console.log(`Canal de voz ${channel.name} deletado por inatividade.`);
                        }
                    }, 20000); // 20 segundos
                }, Math.max(0, 120 * 1000 - timeSinceInactivity)); // Tempo restante até a segunda verificação
            }
        } else {
            inactivityStartTime = null;
            firstWarningSent = false;
            secondWarningSent = false;
            inactivityTimeout1 = null;
            inactivityTimeout2 = null;
            const dbChannelsCollection = await getChannelsCollection();
            await dbChannelsCollection.updateOne(
                { channelId: channel.id },
                { $unset: { inactivityStartTime: "" } }
            );
        }
    }, 10000); // Verificar a cada 10 segundos

    channel.client.on('voiceStateUpdate', (oldState, newState) => {
        if (oldState.channelId !== newState.channelId && newState.channelId === channel.id) {
            // Reset inactivity monitoring
            inactivityStartTime = null;
            firstWarningSent = false;
            secondWarningSent = false;
            clearTimeout(inactivityTimeout1);
            clearTimeout(inactivityTimeout2);
            console.log(`Inatividade do canal de voz ${channel.name} resetada devido a interação do usuário.`);
        }
    });
}

function getCategoryForChannel(interaction) {
    return interaction.channel.parentId || process.env.CATEGORY_ID_1;
}

function getResponseByCategory(categoryId, responses) {
    if (categoryId === process.env.CATEGORY_ID_1) {
        return responses.pt;
    } else if (categoryId === process.env.CATEGORY_ID_2) {
        return responses.es;
    } else if (categoryId === process.env.CATEGORY_ID_3) {
        return responses.en;
    } else if (categoryId === process.env.CATEGORY_ID_4) {
        return responses.pt;
    }
    return responses.pt; // Default
}

module.exports = { checkInactiveChannels, monitorChannelActivity, getCategoryForChannel, getResponseByCategory };
