const { Client, Intents } = require('discord.js');
const { handleMenuCommand } = require('./handleMenuCommand');
const { handleInteraction } = require('./interactionHandlers');

const client = new Client({ intents: [Intents.FLAGS.GUILDS, Intents.FLAGS.GUILD_MESSAGES, Intents.FLAGS.GUILD_VOICE_STATES] });

client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}`);
});

client.on('interactionCreate', async (interaction) => {
    if (interaction.isCommand()) {
        if (interaction.commandName === 'voicemaker') {
            await handleMenuCommand(interaction);
        }
    }

    if (interaction.isButton()) {
        await handleInteraction(interaction);
    }
});

client.login(process.env.BOT_TOKEN);
