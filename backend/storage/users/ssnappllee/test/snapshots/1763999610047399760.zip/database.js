const { MongoClient } = require('mongodb');

const uri = process.env.MONGODB_URI;
const client = new MongoClient(uri);

let database;

async function connectToMongo() {
    try {
        await client.connect();
        database = client.db('TREX');
        console.log('Connected to database');

        // Verificar e criar a coleção 'channels' se não existir
        const collections = await database.listCollections({ name: 'voice_temp_channels' }).toArray();
        if (collections.length === 0) {
            await database.createCollection('voice_temp_channels');
            console.log('Collection "Voice Channels" created');
        }
    } catch (err) {
        console.error('Falha ao conectar ao MongoDB', err);
    }
}

async function getDB() {
    if (!database) {
        await connectToMongo();
    }
    return database;
}

async function getChannelsCollection() {
    const db = await getDB();
    return db.collection('voice_temp_channels');
}

module.exports = { connectToMongo, getDB, getChannelsCollection };
