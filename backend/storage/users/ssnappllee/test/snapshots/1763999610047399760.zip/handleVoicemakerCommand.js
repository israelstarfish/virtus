const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { getCategoryForChannel, getResponseByCategory } = require('./channelUtils');

async function handleVoicemakerCommand(message) { // Atualizado de handleMenuCommand para handleVoicemakerCommand
    const categoryId = getCategoryForChannel(message);

    const embed = new EmbedBuilder()
        .setColor('#FFFF00') // Amarelo
        .setTitle(getResponseByCategory(categoryId, {
            en: '**Play without distraction**',
            es: '**Juega sin distracciones**',
            pt: '**Jogue sem distração**'
        }))
        .setDescription(getResponseByCategory(categoryId, {
            en: `Keep track of the event progress and communicate with your team all in one place. Follow the steps below to create or access a temporary voice channel that only you will have access to.

**🔹 Create channel**
To create your own voice channel, select the "__Create Channel__" button. Once the channel is created, send the generated password to your teammates so they can join.

**🔹 Join channel**
Joining your teammate's voice channel is easy. Just click the "__Join Channel__" button and enter the password that was created for the room.

-# Do not share your password in public channels to avoid complications with your room, as you will have to wait at least 2 minutes to create the next channel.`,
            es: `Haz un seguimiento del progreso del evento y comunícate con tu equipo en un solo lugar. Sigue los pasos a continuación para crear o acceder a un canal de voz temporal al que solo tú tendrás acceso.

**🔹 Crear canal**
Para crear tu propio canal de voz, selecciona el botón "__Crear Canal__". Una vez que se cree el canal, envía la contraseña generada a tus compañeros de equipo para que puedan unirse.

**🔹 Entrar en canal**
Unirse al canal de voz de tu compañero de equipo es fácil. Simplemente haz clic en el botón "__Entrar en el Canal__" y escribe la contraseña que se creó para la sala.

-# No compartas tu contraseña en canales públicos para evitar complicaciones con tu sala, ya que tendrás que esperar al menos 2 minutos para crear el siguiente canal.`,
            pt: `Acompanhe o progresso do evento e comunique-se com sua equipe em apenas um lugar. Siga as etapas abaixo para criar ou acessar um canal de voz temporário ao qual somente você terá acesso.

**🔹 Criar canal**
Para criar seu próprio canal de voz, selecione o botão "__Criar canal__". Depois que o canal for criado, envie a senha gerada para seus colegas de equipe para que eles possam participar.

**🔹 Entrar em canal**
Entrar no canal de voz do seu colega de equipe é fácil. Basta clicar no botão "__Entrar no canal__" e digitar a senha que foi criada para a sala.

-# Não compartilhe sua senha em canais públicos para não complicar sua sala, pois terá de aguardar, no mínimo 2 min para criar próximo canal.`
        }));

    const row = new ActionRowBuilder()
        .addComponents(
            new ButtonBuilder()
                .setCustomId('create_channel')
                .setLabel(getResponseByCategory(categoryId, {
                    en: 'Create Channel',
                    es: 'Crear Canal',
                    pt: 'Criar Canal'
                }))
                .setStyle(ButtonStyle.Primary),
            new ButtonBuilder()
                .setCustomId('join_channel')
                .setLabel(getResponseByCategory(categoryId, {
                    en: 'Join Channel',
                    es: 'Unirse al Canal',
                    pt: 'Entrar no Canal'
                }))
                .setStyle(ButtonStyle.Success) // Verde
        );

    await message.channel.send({ embeds: [embed], components: [row] });
}

module.exports = { handleVoicemakerCommand }; // Atualizado de handleMenuCommand para handleVoicemakerCommand
