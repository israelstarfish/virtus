require('dotenv').config();
const { Client, GatewayIntentBits, Partials } = require('discord.js');
const { connectToMongo } = require('./database');
const { checkInactiveChannels } = require('./channelUtils');
const { handleInteraction, handleVoiceStateUpdate } = require('./interactionHandlers');
const { handleVoicemakerCommand } = require('./handleVoicemakerCommand'); // Atualizado
const fs = require('fs');

const discordClient = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildVoiceStates
    ],
    partials: [Partials.Channel]
});

discordClient.once('ready', () => {
    console.log('Voice Maker connected');
    checkInactiveChannels(discordClient);
});

discordClient.on('messageCreate', async (message) => {
    if (message.author.bot) return;

    const prefix = '!';
    if (!message.content.startsWith(prefix)) return;

    const args = message.content.slice(prefix.length).trim().split(/ +/);
    const command = args.shift().toLowerCase();

    if (command === 'voicemaker') {
        await handleVoicemakerCommand(message); // Atualizado
    }
});

discordClient.on('interactionCreate', async (interaction) => {
    try {
        await handleInteraction(interaction, discordClient);
    } catch (error) {
        console.error('Erro na interação:', error);
        fs.appendFileSync('error.log', `${new Date().toISOString()} - Erro na interação: ${error.message}\n`);
    }
});

discordClient.on('voiceStateUpdate', async (oldState, newState) => {
    try {
        await handleVoiceStateUpdate(oldState, newState, discordClient);
    } catch (error) {
        console.error('Erro na atualização do estado de voz:', error);
        fs.appendFileSync('error.log', `${new Date().toISOString()} - Erro na atualização do estado de voz: ${error.message}\n`);
    }
});

discordClient.on('error', (error) => {
    console.error('Erro do cliente Discord:', error);
    fs.appendFileSync('error.log', `${new Date().toISOString()} - Erro do cliente Discord: ${error.message}\n`);
});

process.on('unhandledRejection', (error) => {
    console.error('Erro não tratado:', error);
    fs.appendFileSync('error.log', `${new Date().toISOString()} - Erro não tratado: ${error.message}\n`);
});

process.on('uncaughtException', (error) => {
    console.error('Exceção não capturada:', error);
    fs.appendFileSync('error.log', `${new Date().toISOString()} - Exceção não capturada: ${error.message}\n`);
});

connectToMongo();
discordClient.login(process.env.DISCORD_TOKEN);
